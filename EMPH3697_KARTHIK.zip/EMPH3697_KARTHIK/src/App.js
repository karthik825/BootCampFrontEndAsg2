import "./App.css";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Cart from "./components/Cart";
import ItemSection from "./components/itemSection";
import { Stack, StackItem } from "@fluentui/react";
import products from "./products.json";
import React from "react";
import { getProductsData } from "./API";

//created the HOC(EMPH3697_KARTHIK)
const withCustomStackItem = (Component, styles) => {
  return (props) => (
    <StackItem style={styles}>
      <Component {...props} />
    </StackItem>
  );
};

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [],
      allProducts: []
    };
  }

  componentDidMount = () => {
    getProductsData().then((products) => {
      console.log(products);
      if (products) {
        this.setState({
          allProducts: products
        })
      }
    })
  }

  render() {
    const ItemSectionWithStackItem = withCustomStackItem(
      ItemSection,
      {width: "80%",
        padding: "40px 0",
        backgroundColor: "#c2c2c2",
        grow: "4",
      }
    );

    const CartWithStackItem = withCustomStackItem(
      Cart,
      {
        width: "20%",
        grow: "2",
      }
    );

    return (
      <div className="App">
        <Header />
        <Stack horizontal horizontalAlign="space-between">
          <ItemSectionWithStackItem products={this.state.allProducts} />
          <CartWithStackItem
            products={this.state.products}/>
        </Stack>
        <Footer />
      </div>
    );
  }
}

export default App;
