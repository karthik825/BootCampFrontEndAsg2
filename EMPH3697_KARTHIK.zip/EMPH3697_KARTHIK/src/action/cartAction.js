// Manages the addition of a new product to the cart and the removal of a product | EMPH3697_KARTHIK
export const AddToCart = (newProduct) => (dispatch, getState) => {
    const { cart: { cartItems } } = getState();
    if (!cartItems.find((product) => product.id === newProduct.id) && newProduct.quantity) {
        dispatch({
            type: "ADD_TO_CART",
            payload: [newProduct, ...cartItems]
        });
    }
};

export const RemoveFromCart = (id) => (dispatch, getState) => {
    const { cart: { cartItems } } = getState();
    dispatch({
        type: "REMOVE_FROM_CART",
        payload: cartItems.filter((product) => product.id !== id) 
    });
};
