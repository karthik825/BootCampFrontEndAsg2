// Establish a Redux store featuring a shopping cart reducer. | EMPH3697_KARTHIK
import { createStore,combineReducers,applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import thunk from "redux-thunk";
import cartReducer from "./reducer/cartReducer";

const reducer = combineReducers({
    cart: cartReducer,
});

const initialState = {};
const middleWare  = [thunk];


const store = createStore(
    reducer,
    initialState,
    composeWithDevTools(applyMiddleware(...middleWare))
)

export default store;