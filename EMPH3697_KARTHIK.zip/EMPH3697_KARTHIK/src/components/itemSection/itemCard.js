import React from "react";
import p1 from "../../images/products/product-1.png";
import { Stack, StackItem } from "@fluentui/react";
import ItemDetails from "./itemDetails";


class ItemCard extends React.Component {
  render() {
    return (
      <Stack
        style={{
          width: "220px",
          backgroundColor: "#fff",
          borderRadius: "10px",
        }}
      >
        <StackItem>
          <img
            style={{ borderRadius: "10px 10px 0 0" }}
            height="150px"
            width="220px"
            src={p1}
            alt="Cart"
          />
        </StackItem>
        <StackItem>
          <ItemDetails productDetails={this.props.productDetails} />
        </StackItem>
      </Stack>
    );
  }
}

export default ItemCard;
