import React, { useState } from "react";
import { Label, Stack, StackItem, Text, mergeStyles } from "@fluentui/react";
import cartIcon from "../../images/common/add-to-cart.png";
import { useDispatch } from "react-redux";
import { AddToCart } from "../../action/cartAction";

const styles = {
  price: mergeStyles({ marginTop: "8px", color: "red", textAlign: "initial" }),
  marginTop: mergeStyles({ marginTop: "8px" }),
  textAlign: mergeStyles({ textAlign: "initial" }),
  stackRoot: { root: { padding: "8px 16px" } },
};

//  defined a custom hook to manage quantity state EMPH3697_KARTHIK
const useQuantity = (initialQuantity = 0) => {
  const [quantity, setQuantity] = useState(initialQuantity);

  //  event handler to update quantity of profuct based on number change of product  EMPH3697_KARTHIK
  const handleQuantityChange = (e) => {
    setQuantity(parseInt(e.target.value));
  };
  return { quantity, handleQuantityChange, setQuantity };
};

//  component to display product details  EMPH3697_KARTHIK
const ProductDetails = ({ productDetails }) => {
  const { quantity, handleQuantityChange, setQuantity } = useQuantity();
  const dispatch = useDispatch();

  //adding the products to the cart  EMPH3697_KARTHIK
  const addToCart = (product, quantity) => {
    dispatch(AddToCart({ ...product, quantity }));
    setQuantity(0);
  };

 // function for rendering prd details EMPH3697_KARTHIK
  const renderDetails = () => (
    <>
      <Label className={styles.textAlign}>{productDetails.name}</Label>
      <Text className={styles.textAlign}>{productDetails.description}</Text>
      <Text className={styles.price} variant="xLarge" block>
        ${productDetails.price * quantity}
      </Text>
    </>
  );
  const renderActions = () => (
    <>
      <Text block> Qty</Text>
      <select
        name="quantity"
        id="product-quantity"
        onChange={handleQuantityChange}
        value={quantity}
      >
        <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
      </select>
      <div className={styles.marginTop}>
        <img
          onClick={() => addToCart(productDetails, quantity)}
          height="30px"
          src={cartIcon}
          alt="Add to Cart"
        />
      </div>
    </>
  );

  return (
    <Stack styles={styles.stackRoot} horizontal horizontalAlign="space-between">
      <StackItem>{renderDetails()}</StackItem>
      <StackItem>{renderActions()}</StackItem>
    </Stack>
  );
};

export default ProductDetails;