import React from "react";
import emptycart from "../images/common/empty-cart.svg";
import { Label, Stack, Text } from "@fluentui/react";
import CartCard from "./cartSection/cartCard";
import { useSelector } from "react-redux";

const Cart = (props) => {
  const cartItems = useSelector((state) => state.cart.cartItems);

  const getEmptyCart = () => {
    return (
      <Stack>
        <img src={emptycart} alt="Cart" />
        <Label>Your Cart is Empty</Label>
        <Text block>Please add something to your cart</Text>
      </Stack>
    );
  };

  const getSelectedProducts = () => {
    const cards = cartItems.map((product) => (
      <CartCard
        key={product.id}
        id={product.id}
        name={product.name}
        desc={product.desc}
        price={product.price}
        quantity={product.quantity}
      />
    ));

    return <>{cards}</>;
  };

  let totalAmount = 0;
  cartItems.forEach((product) => {
    totalAmount += product.price * product.quantity;
  });

  return cartItems.length === 0 ? (
    getEmptyCart()
  ) : (
    <>
      {getSelectedProducts()}
      <div
        style={{
          borderTop: "1px solid grey",
          margin: 8,
        }}
      >
        <span style={{ float: "left" }}>
          <b>Total</b>
        </span>
        <span style={{ float: "right" }}>{totalAmount.toPrecision(5)}</span>
      </div>
    </>
  );
};

export default Cart;
